﻿using DataAccess.DataAccess;
using Microsoft.EntityFrameworkCore;

namespace BusinessLogic.Services
{

    public class AuctionService : IAuctionService
    {
        private readonly IAuctionRepository _auctionRepository;
        private readonly AuctionDbContext _context;

        public AuctionService(IAuctionRepository auctionRepository, AuctionDbContext context)
        {
            _auctionRepository = auctionRepository;
            _context = context;
        }

        public async Task<Auction> CreateAuction(Auction auction)
        {
            return await _auctionRepository.CreateAuction(auction);
        }

        public async Task<bool> DeleteAuction(int id)
        {
            return await _auctionRepository.DeleteAuction(id);
        }

        public async Task<Auction> UpdateAuction(int id, Auction auction)
        {
            return await _auctionRepository.UpdateAuction(id, auction);
        }

        public async Task<IEnumerable<Auction>> GetAllAuctions()
        {
            return await _auctionRepository.GetAllAuctions();
        }

        public async Task<IEnumerable<Auction>> GetAllAuctionsByUserId(int userId)
        {
            return await _auctionRepository.GetAllAuctionsByUserId(userId);
        }
        public async Task<IEnumerable<Auction>> GetOngoingAuctions()
        {
            return await _auctionRepository.GetOngoingAuctions();
        }

        
            public async Task EndAuction(int auctionId)
            {
                var auction = await _auctionRepository.GetAuction(auctionId);

                if (auction != null && auction.EndTime <= DateTime.Now)
                {
                    foreach (var product in auction.Products)
                    {
                        var highestBid = await _context.Bids
                            .Where(b => b.ProductId == product.Id)
                            .OrderByDescending(b => b.Amount)
                            .FirstOrDefaultAsync();

                        if (highestBid != null)
                        {
                            product.IsSold = true;
                            product.BuyerId = highestBid.UserId;
                        }
                    }

                    //await _auctionRepository.SaveChangesAsync();
                }
            }

            public async Task ProcessAuctions()
            {
            var ongoingAuctions = await _auctionRepository.GetOngoingAuctions();

                foreach (var auction in ongoingAuctions)
                {
                    await EndAuction(auction.Id);
                }
            }
        

    }

}
